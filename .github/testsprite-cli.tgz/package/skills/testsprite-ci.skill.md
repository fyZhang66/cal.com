<!--
  User-facing content for `testsprite agent install` (skill: testsprite-ci).
  Body only — name + description frontmatter is emitted by the install wrapper.
  The cursor (.mdc), cline (.clinerules), and antigravity (experimental)
  wrappers reuse this body verbatim and swap only the frontmatter/header.
-->

# TestSprite: gate pull requests in CI

Put `testsprite ci run` into the repo's CI so every pull request's **preview
deployment** is tested before it merges.

This skill uses shipped CLI commands plus `git`, `gh` and the deploy platform's own
CLI. Do **not** call backend APIs directly.

## When to use

- "Add TestSprite to CI / GitHub Actions", "run the tests on every PR", "block merges
  on the tests", "PR gate".
- The project already has tests. If not, run the `testsprite-onboard` skill first.

## When NOT to use

- The user only wants results after each PR deploys — no merge gate, no job ordering:
  recommend the **TestSprite GitHub App** (Portal → project → Integrations) and stop.
  Ask before adding a gate to a project the App already runs: both would test every
  push, twice the credits and two checks per PR.
- A nightly run of a fixed environment: `testsprite ci run --project <id> --env <name>`
  on a `schedule:` trigger. No pull-request context is involved.

## 1. Find out how pull requests get deployed (the shape)

Read `package.json`, `vercel.json` / `netlify.toml`, and `.github/workflows/`, then:

```bash
gh api repos/{owner}/{repo}/deployments --jq '.[] | "\(.environment) \(.ref[0:8]) \(.created_at)"'
```

- **A — the platform deploys every PR** (Vercel / Netlify git integration): preview
  deployment records exist and no workflow deploys. Trigger: `on: deployment_status`.
- **B — the workflow deploys**: a step runs `vercel deploy`, `netlify deploy` or a
  script. Trigger: `on: pull_request`.

Reading the history: judge **preview** and **production** records separately — a PR
gate fires on preview deployments, so production-only means "enable preview deploys
on the platform". A newest preview older than ~90 days is stale. `gh` missing, not
authenticated or a network error is **unknown**, not "not linked". History is evidence,
not configuration: no records can mean "linked, never deployed yet", and old records
can mean "unlinked since". The proof is a real pull request (step 5).

Not linked but the user wants A: connect the repository to the platform's git
integration (Vercel: project → Settings → Git, or `npx vercel git connect` with the
user's approval — never `--yes`), or use shape B instead. Installing the platform's
GitHub App is a browser step only the user can do.

## 2. Pick the environment the gate signs in with

```bash
testsprite project env list <project-id>
```

Prefer `account` (stored credentials) or `public`. `manual` (a recorded session, e.g.
SSO) cannot sign in on a preview origin; `otp` works but one-time codes are limited.
Without `--env` the project's default is written into the workflow **by name**.

## 3. Generate the workflow, then finish it by hand

```bash
testsprite ci init github --project <project-id> --env <name>
```

This writes `.github/workflows/testsprite.yml` with one step marked `REPLACE ME`
(the job fails until it is replaced):

- **A:** change the trigger from `pull_request:` to `deployment_status:` and delete the
  placeholder step; the run then reads the URL from `deployment_status.environment_url`.
  A repo that deploys **several** Vercel projects gets one event per project for the
  same commit — add `&& github.event.deployment.environment == 'Preview – <project>'`
  to the `deployment_status` branch of the `if:`.
- **B:** replace the placeholder's `run:` with the deploy commands, ending in
  `echo "url=<preview address>" >> "$GITHUB_OUTPUT"`. The platform token goes in its
  own repo secret.

Keep what the template fixes: `testsprite ci run … --target-url "$PREVIEW_URL"
--fail-on-skipped --summary-file`, `npm i -g @testsprite/testsprite-cli@latest` (no
version pin — verdicts come from the backend), fork and draft PRs skipped, the upload
step on `if: always()`, and `concurrency` on the **job** (keyed by PR number in B, by
commit in A). Never re-judge pass/fail in YAML (`jq` + `exit 1`): `ci run`'s exit code
is the gate. Regenerate with `--force`; the previous file is kept as `.bak`.

## 4. Secrets

```bash
gh secret set TESTSPRITE_API_KEY        # paste when prompted, or pipe on stdin
```

(`ci init github --set-secret` does the same.) Never put the key in argv, YAML or
logs. A non-production endpoint goes in the workflow `env:` as `TESTSPRITE_API_URL`.
B also needs the platform's deploy token as a secret.

## 5. Prove it on one real pull request

Commit and push the workflow on a branch, open a PR that is **not a draft** and has
**no merge conflicts**, and watch the `TestSprite / gate` check. The log shows
`Dispatched N tests.` then `CI run: x/y passed …`; the job summary is the execution
report (the same content as the App's PR comment); a `testsprite-results` artifact
holds `testsprite-summary.json`. Then suggest making the check **required** in branch
protection. In shape A the workflow file runs **at the deployed commit**, so the PR
branch itself is enough — nothing has to be merged first.

If nothing ran: a draft PR prints `Skipping draft pull request` and exits 0 with no
summary (mark it ready and re-run the job); a PR with merge conflicts never fires
`pull_request` workflows and GitHub shows no error; in shape A check that a
`deployment_status` with state `success` arrived for that commit (production
deployments are filtered out by the `if:`).

## Reading the result

- The check is `ci run`'s exit code: 1 = a test failed, 7 = timeout or an unsupported
  backend, 5 = configuration. A summary opening with a **CI gate** warning means the
  CLI's own counts differ from the report (a run it could not read, a timeout) — the
  check is right, the report is the server's view of the execution.
- `exit 7` with "did not confirm the single-execution admission mode" = the backend is
  too old for `ci run`; the dispatched runs were cancelled and refunded.
- Screenshots in the report are capped at 12 per execution; later rows show `—`.
- Shape A is per commit: a new push starts its own run against its own preview, and
  cancelling the job only stops the CLI — the execution keeps running and reports in
  the Portal.
- Backend tests use the URL baked into their code, not `--target-url`.
- Testing `ci run` locally: a shell that exports `TESTSPRITE_API_URL` or
  `TESTSPRITE_API_KEY` overrides `--profile` — a `fetch failed` against a healthy API is
  usually that. Check `env | grep TESTSPRITE_` first.

## Don'ts

- Don't add a CI gate next to the GitHub App on the same project without asking.
- Don't run `vercel link --yes`; don't pass secrets as arguments.
- Don't pin the CLI version in the workflow; don't parse the summary to decide the verdict.
- Don't commit a loopback or private `--target-url` (`ci run` refuses it).
- Don't skip step 5: a workflow that has not run on a real PR is not onboarded.
